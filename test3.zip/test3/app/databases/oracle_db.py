from typing import List, Optional, Tuple
import oracledb
from app.databases.base import BaseDatabase
from app.models import User, UserUpdate
from app.config import config


class OracleDatabase(BaseDatabase):
    def __init__(self):
        super().__init__(name="oracle", display_name="Oracle Database")
        self.conn = None

    def _get_connection(self):
        dsn = f"{config.ORACLE_HOST}:{config.ORACLE_PORT}/{config.ORACLE_SERVICE}"
        return oracledb.connect(
            user=config.ORACLE_USER,
            password=config.ORACLE_PASSWORD,
            dsn=dsn,
            tcp_connect_timeout=10.0
        )

    def connect(self) -> bool:
        try:
            self.init_schema()
            self.conn = self._get_connection()
            self.is_ready = True
            return True
        except Exception:
            self.is_ready = False
            return False

    def disconnect(self) -> None:
        if self.conn:
            try:
                self.conn.close()
            except Exception:
                pass
            self.conn = None
        self.is_ready = False

    def init_schema(self) -> None:
        conn = self._get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    DECLARE
                        v_count NUMBER;
                    BEGIN
                        SELECT COUNT(*) INTO v_count FROM user_tables WHERE table_name = 'USERS';
                        IF v_count = 0 THEN
                            EXECUTE IMMEDIATE '
                                CREATE TABLE users (
                                    id NUMBER PRIMARY KEY,
                                    full_name VARCHAR2(255) NOT NULL,
                                    profession VARCHAR2(255) NOT NULL,
                                    department VARCHAR2(255),
                                    salary NUMBER,
                                    created_at VARCHAR2(50)
                                )
                            ';
                        END IF;
                    END;
                """)
            conn.commit()
        finally:
            conn.close()

    def check_connection(self) -> Tuple[bool, str]:
        try:
            conn = self._get_connection()
            with conn.cursor() as cur:
                cur.execute("SELECT 1 FROM dual")
                cur.fetchone()
            conn.close()
            self.is_ready = True
            return True, "Подключено (Oracle Database)"
        except Exception as e:
            self.is_ready = False
            return False, f"Ошибка Oracle: {str(e)}"

    def count(self) -> int:
        conn = self._get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT COUNT(*) FROM users")
                row = cur.fetchone()
                if not row:
                    return 0
                (total,) = row
                return int(total)
        finally:
            conn.close()

    def get_max_id(self) -> int:
        conn = self._get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT NVL(MAX(id), 0) FROM users")
                row = cur.fetchone()
                if not row:
                    return 0
                (max_id,) = row
                return int(max_id or 0)
        finally:
            conn.close()

    def search(self, query: str = "", limit: int = 50) -> List[User]:
        conn = self._get_connection()
        try:
            with conn.cursor() as cur:
                if query.strip():
                    like_q = f"%{query.strip().lower()}%"
                    cur.execute(
                        "SELECT id, full_name, profession, department, salary, created_at "
                        "FROM users WHERE LOWER(full_name) LIKE :1 OR LOWER(profession) LIKE :2 OR LOWER(NVL(department, '')) LIKE :3 "
                        "ORDER BY id ASC FETCH FIRST :4 ROWS ONLY",
                        (like_q, like_q, like_q, int(limit))
                    )
                else:
                    cur.execute(
                        "SELECT id, full_name, profession, department, salary, created_at "
                        "FROM users ORDER BY id ASC FETCH FIRST :1 ROWS ONLY",
                        (int(limit),)
                    )
                rows = cur.fetchall()
                result: List[User] = []
                for uid, full_name, profession, department, salary, created_at in rows:
                    result.append(
                        User(
                            id=int(uid),
                            full_name=full_name,
                            profession=profession,
                            department=department,
                            salary=int(salary) if salary is not None else 0,
                            created_at=created_at
                        )
                    )
                return result
        finally:
            conn.close()

    def get_by_id(self, user_id: int) -> Optional[User]:
        conn = self._get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT id, full_name, profession, department, salary, created_at FROM users WHERE id = :1",
                    (user_id,)
                )
                row = cur.fetchone()
                if not row:
                    return None
                uid, full_name, profession, department, salary, created_at = row
                return User(
                    id=int(uid),
                    full_name=full_name,
                    profession=profession,
                    department=department,
                    salary=int(salary) if salary is not None else 0,
                    created_at=created_at
                )
        finally:
            conn.close()

    def insert(self, user: User) -> bool:
        conn = self._get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM users WHERE id = :1", (user.id,))
                cur.execute(
                    "INSERT INTO users (id, full_name, profession, department, salary, created_at) "
                    "VALUES (:1, :2, :3, :4, :5, :6)",
                    (
                        user.id,
                        user.full_name,
                        user.profession,
                        user.department or "",
                        user.salary if user.salary is not None else 0,
                        user.created_at or ""
                    )
                )
            conn.commit()
            return True
        finally:
            conn.close()

    def insert_many(self, users: List[User]) -> int:
        if not users:
            return 0
        conn = self._get_connection()
        try:
            with conn.cursor() as cur:
                ids = [(u.id,) for u in users]
                cur.executemany("DELETE FROM users WHERE id = :1", ids)
                data = [
                    (
                        u.id,
                        u.full_name,
                        u.profession,
                        u.department or "",
                        u.salary if u.salary is not None else 0,
                        u.created_at or ""
                    )
                    for u in users
                ]
                cur.executemany(
                    "INSERT INTO users (id, full_name, profession, department, salary, created_at) "
                    "VALUES (:1, :2, :3, :4, :5, :6)",
                    data
                )
            conn.commit()
            return len(users)
        finally:
            conn.close()

    def update(self, user_or_id, data: Optional[UserUpdate] = None) -> bool:
        conn = self._get_connection()
        try:
            with conn.cursor() as cur:
                if isinstance(user_or_id, User):
                    u = user_or_id
                    cur.execute(
                        "UPDATE users SET full_name = :1, profession = :2, department = :3, salary = :4 WHERE id = :5",
                        (u.full_name, u.profession, u.department or "", u.salary if u.salary is not None else 0, u.id)
                    )
                else:
                    user_id = int(user_or_id)
                    existing = self.get_by_id(user_id)
                    if not existing:
                        return False
                    full_name = data.full_name if (data and data.full_name is not None) else existing.full_name
                    profession = data.profession if (data and data.profession is not None) else existing.profession
                    department = data.department if (data and data.department is not None) else existing.department
                    salary = data.salary if (data and data.salary is not None) else existing.salary
                    cur.execute(
                        "UPDATE users SET full_name = :1, profession = :2, department = :3, salary = :4 WHERE id = :5",
                        (full_name, profession, department or "", salary if salary is not None else 0, user_id)
                    )
                updated = cur.rowcount > 0
            conn.commit()
            return updated
        finally:
            conn.close()

    def delete(self, user_id: int) -> bool:
        conn = self._get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM users WHERE id = :1", (user_id,))
                deleted = cur.rowcount > 0
            conn.commit()
            return deleted
        finally:
            conn.close()

    def clear_all(self) -> None:
        conn = self._get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("TRUNCATE TABLE users")
            conn.commit()
        finally:
            conn.close()