from typing import List, Optional, Tuple
import pymssql
from app.databases.base import BaseDatabase
from app.models import User, UserUpdate
from app.config import config


class MSSQLDatabase(BaseDatabase):
    def __init__(self):
        super().__init__(name="mssql", display_name="Microsoft SQL Server")
        self.conn = None

    def _get_connection(self):
        return pymssql.connect(
            server=config.MSSQL_HOST,
            port=config.MSSQL_PORT,
            user=config.MSSQL_USER,
            password=config.MSSQL_PASSWORD,
            database=config.MSSQL_DB,
            autocommit=True,
            login_timeout=5,
            timeout=10
        )

    def connect(self) -> bool:
        try:
            self.init_schema()
            self.conn = self._get_connection()
            self.is_ready = True
            return True
        except Exception:
            self.is_ready = False
            return False

    def disconnect(self) -> None:
        if self.conn:
            try:
                self.conn.close()
            except Exception:
                pass
            self.conn = None
        self.is_ready = False

    def init_schema(self) -> None:
        master_conn = pymssql.connect(
            server=config.MSSQL_HOST,
            port=config.MSSQL_PORT,
            user=config.MSSQL_USER,
            password=config.MSSQL_PASSWORD,
            database="master",
            autocommit=True,
            login_timeout=5
        )
        try:
            cur = master_conn.cursor()
            cur.execute(
                f"IF DB_ID(N'{config.MSSQL_DB}') IS NULL CREATE DATABASE [{config.MSSQL_DB}];"
            )
        finally:
            master_conn.close()

        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""
                IF OBJECT_ID(N'dbo.users', N'U') IS NULL
                BEGIN
                    CREATE TABLE users (
                        id INT PRIMARY KEY,
                        full_name NVARCHAR(255) NOT NULL,
                        profession NVARCHAR(255) NOT NULL,
                        department NVARCHAR(255) NULL,
                        salary INT NULL,
                        created_at NVARCHAR(50) NULL
                    );
                END
            """)
        finally:
            conn.close()

    def check_connection(self) -> Tuple[bool, str]:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT 1;")
            cursor.fetchone()
            conn.close()
            self.is_ready = True
            return True, "Подключено (Microsoft SQL Server)"
        except Exception as e:
            self.is_ready = False
            return False, f"Ошибка MS SQL: {str(e)}"

    def count(self) -> int:
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM users;")
            row = cursor.fetchone()
            if not row:
                return 0
            (total,) = row
            return int(total)
        finally:
            conn.close()

    def get_max_id(self) -> int:
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COALESCE(MAX(id), 0) FROM users;")
            row = cursor.fetchone()
            if not row:
                return 0
            (max_id,) = row
            return int(max_id or 0)
        finally:
            conn.close()

    def search(self, query: str = "", limit: int = 50) -> List[User]:
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            if query.strip():
                like_q = f"%{query.strip()}%"
                cursor.execute(
                    f"SELECT TOP ({int(limit)}) id, full_name, profession, department, salary, created_at "
                    "FROM users WHERE full_name LIKE %s OR profession LIKE %s OR department LIKE %s "
                    "ORDER BY id ASC;",
                    (like_q, like_q, like_q)
                )
            else:
                cursor.execute(
                    f"SELECT TOP ({int(limit)}) id, full_name, profession, department, salary, created_at "
                    "FROM users ORDER BY id ASC;"
                )
            rows = cursor.fetchall()
            return [
                User(
                    id=uid,
                    full_name=full_name,
                    profession=profession,
                    department=department,
                    salary=salary,
                    created_at=created_at
                )
                for uid, full_name, profession, department, salary, created_at in rows
            ]
        finally:
            conn.close()

    def get_by_id(self, user_id: int) -> Optional[User]:
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id, full_name, profession, department, salary, created_at FROM users WHERE id = %s;",
                (user_id,)
            )
            row = cursor.fetchone()
            if not row:
                return None
            uid, full_name, profession, department, salary, created_at = row
            return User(
                id=uid,
                full_name=full_name,
                profession=profession,
                department=department,
                salary=salary,
                created_at=created_at
            )
        finally:
            conn.close()

    def insert(self, user: User) -> bool:
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM users WHERE id = %s;", (user.id,))
            cursor.execute(
                "INSERT INTO users (id, full_name, profession, department, salary, created_at) "
                "VALUES (%s, %s, %s, %s, %s, %s);",
                (user.id, user.full_name, user.profession, user.department, user.salary, user.created_at)
            )
            return True
        finally:
            conn.close()

    def insert_many(self, users: List[User]) -> int:
        if not users:
            return 0
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            ids = [u.id for u in users]
            for i in range(0, len(ids), 500):
                chunk = ids[i:i + 500]
                placeholders = ",".join(["%s"] * len(chunk))
                cursor.execute(f"DELETE FROM users WHERE id IN ({placeholders});", tuple(chunk))

            data = [(u.id, u.full_name, u.profession, u.department, u.salary, u.created_at) for u in users]
            cursor.executemany(
                "INSERT INTO users (id, full_name, profession, department, salary, created_at) "
                "VALUES (%s, %s, %s, %s, %s, %s);",
                data
            )
            return len(users)
        finally:
            conn.close()

    def update(self, user_or_id, data: Optional[UserUpdate] = None) -> bool:
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            if isinstance(user_or_id, User):
                u = user_or_id
                cursor.execute(
                    "UPDATE users SET full_name = %s, profession = %s, department = %s, salary = %s WHERE id = %s;",
                    (u.full_name, u.profession, u.department, u.salary, u.id)
                )
            else:
                user_id = int(user_or_id)
                existing = self.get_by_id(user_id)
                if not existing:
                    return False
                full_name = data.full_name if (data and data.full_name is not None) else existing.full_name
                profession = data.profession if (data and data.profession is not None) else existing.profession
                department = data.department if (data and data.department is not None) else existing.department
                salary = data.salary if (data and data.salary is not None) else existing.salary
                cursor.execute(
                    "UPDATE users SET full_name = %s, profession = %s, department = %s, salary = %s WHERE id = %s;",
                    (full_name, profession, department, salary, user_id)
                )
            return cursor.rowcount > 0
        finally:
            conn.close()

    def delete(self, user_id: int) -> bool:
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM users WHERE id = %s;", (user_id,))
            return cursor.rowcount > 0
        finally:
            conn.close()

    def clear_all(self) -> None:
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("TRUNCATE TABLE users;")
        finally:
            conn.close()
