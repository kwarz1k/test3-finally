import threading
import time
from collections import deque
from typing import Dict, List, Any, Optional


class StatsService:
    """Хранит историю операций и считает среднюю скорость по каждой СУБД и типу операции."""

    def __init__(self, max_logs: int = 300):
        self._lock = threading.Lock()
        self._logs: deque = deque(maxlen=max_logs)
        self._metrics: Dict[str, Dict[str, List[float]]] = {}

    def log_operation(
        self,
        db_name: str,
        operation: str,
        duration_ms: float,
        affected_rows: int = 0,
        details: str = "",
        success: bool = True,
        error: Optional[str] = None
    ) -> Dict[str, Any]:
        op_upper = operation.upper()
        now_str = time.strftime("%H:%M:%S")
        entry = {
            "time_str": now_str,
            "timestamp": now_str,
            "db_name": db_name,
            "db": db_name,
            "operation": op_upper,
            "duration_ms": round(duration_ms, 3),
            "affected_rows": affected_rows,
            "details": details,
            "success": success,
            "error": error
        }
        with self._lock:
            self._logs.appendleft(entry)
            if success and op_upper in ("SELECT", "INSERT", "UPDATE", "DELETE"):
                if db_name not in self._metrics:
                    self._metrics[db_name] = {"SELECT": [], "INSERT": [], "UPDATE": [], "DELETE": []}
                self._metrics[db_name][op_upper].append(duration_ms)
                if len(self._metrics[db_name][op_upper]) > 100:
                    self._metrics[db_name][op_upper] = self._metrics[db_name][op_upper][-100:]
        return entry

    def get_aggregated_stats(self) -> Dict[str, Any]:
        with self._lock:
            db_keys = ["postgres", "sqlite", "mysql", "mongodb", "mssql", "oracle"]
            chart_labels = ["PostgreSQL", "SQLite", "MySQL", "MongoDB", "MsSQL", "Oracle"]

            op_styles = [
                ("SELECT", "#38bdf8"),
                ("INSERT", "#10b981"),
                ("UPDATE", "#f59e0b"),
                ("DELETE", "#f43f5e"),
            ]

            averages: Dict[str, Dict[str, float]] = {}
            for db in db_keys:
                averages[db] = {}
                db_data = self._metrics.get(db, {})
                for op, _ in op_styles:
                    vals = db_data.get(op, [])
                    averages[db][op] = round(sum(vals) / len(vals), 3) if vals else 0.0

            datasets = []
            for op, color in op_styles:
                datasets.append({
                    "label": op,
                    "data": [averages[db][op] for db in db_keys],
                    "backgroundColor": color,
                    "borderRadius": 6
                })

            return {
                "chart_labels": chart_labels,
                "datasets": datasets,
                "averages": averages
            }

    def get_recent_logs(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._logs)[:limit]

    def get_summary(self) -> Dict[str, Any]:
        agg = self.get_aggregated_stats()
        with self._lock:
            db_keys = ["postgres", "sqlite", "mysql", "mongodb", "mssql", "oracle"]
            counts: Dict[str, Dict[str, int]] = {}
            for db in db_keys:
                counts[db] = {}
                db_data = self._metrics.get(db, {})
                for op in ("SELECT", "INSERT", "UPDATE", "DELETE"):
                    counts[db][op] = len(db_data.get(op, []))

            return {
                "averages": agg["averages"],
                "counts": counts,
                "logs": list(self._logs)[:60]
            }

    def clear_logs(self) -> None:
        with self._lock:
            self._logs.clear()
            self._metrics.clear()

    def clear(self) -> None:
        self.clear_logs()


stats_service = StatsService()
