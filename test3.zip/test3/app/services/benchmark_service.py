import time
import random
from typing import Dict, Any, List
from app.databases.manager import db_manager
from app.databases.base import BaseDatabase
from app.models import User, UserUpdate
from app.services.stats_service import stats_service


class BenchmarkService:
    """
    Запускает серию CRUD-операций (SELECT, INSERT, UPDATE, DELETE) по всем доступным СУБД,
    замеряет точное время выполнения каждой операции и записывает в статистику.
    """

    def _get_databases(self) -> List[BaseDatabase]:
        for attr_name in ("databases", "dbs", "_databases", "_dbs"):
            val = getattr(db_manager, attr_name, None)
            if isinstance(val, dict):
                return [db for db in val.values() if isinstance(db, BaseDatabase)]
            if isinstance(val, list):
                return [db for db in val if isinstance(db, BaseDatabase)]
        return [
            val for val in vars(db_manager).values()
            if isinstance(val, BaseDatabase)
        ]

    def run_suite(self, iterations: int = 5) -> Dict[str, Any]:
        results: Dict[str, Dict[str, Any]] = {}
        all_dbs = self._get_databases()
        active_dbs = [db for db in all_dbs if getattr(db, "is_ready", True)]
        if not active_dbs:
            active_dbs = all_dbs

        for db in active_dbs:
            db_summary: Dict[str, Any] = {
                "SELECT": [],
                "INSERT": [],
                "UPDATE": [],
                "DELETE": [],
                "errors": []
            }

            base_temp_id = 90000 + random.randint(1, 5000)

            # 1. Тест SELECT (поиск по строке)
            queries = ["Инженер", "Разработчик", "Аналитик", "Менеджер", "Тестировщик"]
            for i in range(iterations):
                q = queries[i % len(queries)]
                start = time.perf_counter()
                try:
                    found = db.search(q, limit=20)
                    dur = (time.perf_counter() - start) * 1000.0
                    db_summary["SELECT"].append(round(dur, 3))
                    stats_service.log_operation(
                        db_name=db.name,
                        operation="SELECT",
                        duration_ms=dur,
                        affected_rows=len(found),
                        details=f"Бенчмарк: поиск '{q}'",
                        success=True
                    )
                except Exception as e:
                    dur = (time.perf_counter() - start) * 1000.0
                    db_summary["errors"].append(f"SELECT: {str(e)}")
                    stats_service.log_operation(
                        db_name=db.name,
                        operation="SELECT",
                        duration_ms=dur,
                        affected_rows=0,
                        details=f"Ошибка бенчмарка SELECT: {str(e)}",
                        success=False,
                        error=str(e)
                    )

            # 2. Тест INSERT (вставка новых временных записей)
            inserted_ids: List[int] = []
            for i in range(iterations):
                temp_id = base_temp_id + i
                temp_user = User(
                    id=temp_id,
                    full_name=f"Тестовый Пользователь {i}",
                    profession="Тестировщик производительности",
                    department="Бенчмарк",
                    salary=150000,
                    created_at=time.strftime("%Y-%m-%d %H:%M:%S")
                )
                start = time.perf_counter()
                try:
                    ok = db.insert(temp_user)
                    dur = (time.perf_counter() - start) * 1000.0
                    if ok:
                        inserted_ids.append(temp_id)
                        db_summary["INSERT"].append(round(dur, 3))
                    stats_service.log_operation(
                        db_name=db.name,
                        operation="INSERT",
                        duration_ms=dur,
                        affected_rows=1 if ok else 0,
                        details=f"Бенчмарк: вставка id={temp_id}",
                        success=bool(ok)
                    )
                except Exception as e:
                    dur = (time.perf_counter() - start) * 1000.0
                    db_summary["errors"].append(f"INSERT: {str(e)}")
                    stats_service.log_operation(
                        db_name=db.name,
                        operation="INSERT",
                        duration_ms=dur,
                        affected_rows=0,
                        details=f"Ошибка бенчмарка INSERT: {str(e)}",
                        success=False,
                        error=str(e)
                    )

            # 3. Тест UPDATE (обновление созданных записей)
            for idx, temp_id in enumerate(inserted_ids):
                update_data = UserUpdate(
                    full_name=f"Обновленный Пользователь {idx}",
                    profession="Старший тестировщик",
                    department="QA",
                    salary=210000
                )
                start = time.perf_counter()
                try:
                    ok = db.update(temp_id, update_data)
                    dur = (time.perf_counter() - start) * 1000.0
                    if ok:
                        db_summary["UPDATE"].append(round(dur, 3))
                    stats_service.log_operation(
                        db_name=db.name,
                        operation="UPDATE",
                        duration_ms=dur,
                        affected_rows=1 if ok else 0,
                        details=f"Бенчмарк: обновление id={temp_id}",
                        success=bool(ok)
                    )
                except Exception as e:
                    dur = (time.perf_counter() - start) * 1000.0
                    db_summary["errors"].append(f"UPDATE: {str(e)}")
                    stats_service.log_operation(
                        db_name=db.name,
                        operation="UPDATE",
                        duration_ms=dur,
                        affected_rows=0,
                        details=f"Ошибка бенчмарка UPDATE: {str(e)}",
                        success=False,
                        error=str(e)
                    )

            # 4. Тест DELETE (удаление временных записей)
            for temp_id in inserted_ids:
                start = time.perf_counter()
                try:
                    ok = db.delete(temp_id)
                    dur = (time.perf_counter() - start) * 1000.0
                    if ok:
                        db_summary["DELETE"].append(round(dur, 3))
                    stats_service.log_operation(
                        db_name=db.name,
                        operation="DELETE",
                        duration_ms=dur,
                        affected_rows=1 if ok else 0,
                        details=f"Бенчмарк: удаление id={temp_id}",
                        success=bool(ok)
                    )
                except Exception as e:
                    dur = (time.perf_counter() - start) * 1000.0
                    db_summary["errors"].append(f"DELETE: {str(e)}")
                    stats_service.log_operation(
                        db_name=db.name,
                        operation="DELETE",
                        duration_ms=dur,
                        affected_rows=0,
                        details=f"Ошибка бенчмарка DELETE: {str(e)}",
                        success=False,
                        error=str(e)
                    )

            averages = {}
            for op in ["SELECT", "INSERT", "UPDATE", "DELETE"]:
                vals = db_summary[op]
                averages[op] = round(sum(vals) / len(vals), 3) if vals else 0.0

            results[db.name] = {
                "iterations": iterations,
                "averages_ms": averages,
                "raw_ms": db_summary
            }

        return {
            "status": "completed",
            "iterations_per_op": iterations,
            "databases_tested": [db.name for db in active_dbs],
            "results": results,
            "stats": stats_service.get_summary()
        }

    def run_benchmark(self, iterations: int = 5) -> Dict[str, Any]:
        return self.run_suite(iterations=iterations)


benchmark_service = BenchmarkService()
